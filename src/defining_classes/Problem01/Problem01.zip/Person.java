package Problem01;

/**
 * Created by Chilly on 23.10.2017 г..
 */
public class Person {
    private String name;
    private int age;
}
