package Problem03;

/**
 * Created by Chilly on 24.10.2017 г..
 */
public class Person {
    public String name;
    public int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}