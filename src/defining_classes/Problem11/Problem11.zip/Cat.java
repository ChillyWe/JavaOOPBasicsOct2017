package Problem11;

/**
 * Created by Chilly on 30.10.2017 г..
 */
public class Cat {
    protected String name;

    public Cat(String name) {
        this.name = name;
    }
}