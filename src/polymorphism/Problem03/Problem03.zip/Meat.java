package Problem03;

/**
 * Created by Chilly on 06.11.2017 г..
 */
public class Meat extends Food {
    public Meat(int foodQuantity) {
        super(foodQuantity);
    }
}