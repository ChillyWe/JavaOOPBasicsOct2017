package Problem03;

/**
 * Created by Chilly on 06.11.2017 г..
 */
public class Vegetable extends Food {
    public Vegetable(int foodQuantity) {
        super(foodQuantity);
    }
}